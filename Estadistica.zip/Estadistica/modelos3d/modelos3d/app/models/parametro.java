package models;

public class parametro{
	public Double x1;
	public Double x2;
	public Double y;
}