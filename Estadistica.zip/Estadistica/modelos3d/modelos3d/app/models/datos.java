package models;

import java.math.BigDecimal;

public class datos {
	
	public Double [] x1;
	public Double [] x2;
	public Double [] z;
	
	public int n;
	
	public Double[][] matriz;
	
	public Double LINEAL_a0;
	public Double LINEAL_a1;
	public Double LINEAL_a2;
	public Double [] LINEAL_param_X1;
	public Double [] LINEAL_param_X2;
	public double[] LINEAL_param_Y;
	
	public Double CUADRATICO_a0;
	public Double CUADRATICO_a1;
	public Double CUADRATICO_a2;
	public Double CUADRATICO_a3;
	public Double CUADRATICO_a4;
	public Double CUADRATICO_a5;
	
	public Double [] CUADRATICO_param_X1;
	public Double [] CUADRATICO_param_X2;
	public double[] CUADRATICO_param_Y;
	
	
	public Double R_2__1;
	public Double R_2__2;
	public Double R__1;
	public Double R__2;
	
	
	

}
